interface PersonalModel {
 
    
   
      firstName: string;
      lastName: string;
      mobileNumber:string;
     
      description:string;
     
      phoneNumber:string ;
      
      IsActive:boolean;
      userId:number;
       id:number;
      
    }
    
    export default PersonalModel;
 