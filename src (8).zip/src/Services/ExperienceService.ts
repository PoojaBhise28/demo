import axios from "axios";
import ExperienceModel from "../Model/ExperienceModel";

export async function GetExperienceInfoAsync(
    id: number
  ): Promise<{ data: ExperienceModel[] }> {
    try {
      // const token = localStorage.getItem("Token"); // Replace 'YOUR_BEARER_TOKEN' with your actual bearer token
  
      const response = await axios.get<ExperienceModel[]>(
        `http://localhost:5203/api/Experienceinfo/ByUserId/` + id
      );
      //console.log(response);
      return response;
    } catch (error) {
      throw new Error("Failed to update leave data: " + (error as Error).message);
    }
  }