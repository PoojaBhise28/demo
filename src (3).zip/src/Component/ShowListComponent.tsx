import { useState } from 'react';
import "../Style/showlist.css"
import PersonalModel from '../Model/PersonalModel';
import AddressModel from '../Model/AddressModel';
import AcademicModel from '../Model/AcademicModel';
import EmployeModel from '../Model/EmployeModel';
import ExperienceModel from '../Model/ExperienceModel';

export default function ShowListComponent() {
  const [personalInfo, setPersonalInfo] = useState<PersonalModel[]>([]);
  const [Addressinfo, setAddressinfo] = useState<AddressModel[]>([]);
  const [Academicinfo, setAcademicinfo] = useState<AcademicModel[]>([]);
  const [Employeeinfo, setEmployeeinfo] = useState<EmployeModel[]>([]);
  const [Experienceinfo, setExperienceinfo] = useState<ExperienceModel[]>([]);

  return (
    <div className="show-container">
      <div className="showPersonalInfo">
        <h1>Personal Data</h1>
        <table className="contact-list">
          <thead>
            <tr>
              <th>Sr. no</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Phone Number</th>
              <th>Mobile Number</th>
              <th>Description</th>
              <th>Update</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {personalInfo.map((data, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{data.firstName}</td>
                <td>{data.lastName}</td>
                <td>{data.phoneNumber}</td>
                <td>{data.mobileNumber}</td>
                <td>{data.description}</td>
                <td>
                  <button type="button">Edit</button>
                </td>
                <td>
                  <button type="button">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* <div className="showAcademic">
        <h1>Academic Details</h1>
        <table className="contact-list">
          <thead>
            <tr>
              <th>Sr. no</th>
              <th>Institution Name</th>
              <th>Degree</th>
              <th>Start Year</th>
              <th>End Year</th>
              <th>Update</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {Academicinfo.map((data, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{data.InstitutionName}</td>
                <td>{data.Degree}</td>
                <td>{data.StartYear}</td>
                <td>{data.EndYear}</td>
                <td>
                  <button type="button">Edit</button>
                </td>
                <td>
                  <button type="button">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="showAddress">
        <h1>Address Details</h1>
        <table className="contact-list">
          <thead>
            <tr>
              <th>Sr. no</th>
              <th>Address</th>
              <th>City</th>
              <th>State Id</th>
              <th>Country Id</th>
              <th>Description</th>
              <th>Update</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {Addressinfo.map((data, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{data.Address}</td>
                <td>{data.City}</td>
                <td>{data.StateId}</td>
                <td>{data.CountryId}</td>
                <td>
                  <button type="button">Edit</button>
                </td>
                <td>
                  <button type="button">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="showEmployee">
        <h1>Employee Details</h1>
        <table className="contact-list">
          <thead>
            <tr>
              <th>Sr. no</th>
              <th>CompanyName</th>
              <th>NoticePeriod</th>
              <th>CurrentCTC</th>
              <th>ExpectedCTC</th>
              <th>Update</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {Employeeinfo.map((data, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{data.CompanyName}</td>
                <td>{data.NoticePeriod}</td>
                <td>{data.CurrentCTC}</td>
                <td>{data.ExpectedCTC}</td>
                <td>
                  <button type="button">Edit</button>
                </td>
                <td>
                  <button type="button">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="showExperience">
        <h1>Experience Details</h1>
        <table className="contact-list">
          <thead>
            <tr>
              <th>Sr. no</th>
              <th>CompanyName</th>
              <th>DesignationId</th>
              <th>StartYear</th>
              <th>EndYear</th>
              <th>Update</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {Experienceinfo.map((data, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{data.CompanyName}</td>
                <td>{data.DesignationId}</td>
                <td>{data.StartYear}</td>
                <td>{data.EndYear}</td>
                <td>
                  <button type="button">Edit</button>
                </td>
                <td>
                  <button type="button">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div> */}
    </div>
  );
}
