interface UserModel {
    emailAddress: string;
    password: string;
   
      
      userId:number;
      id:number;
      
    }
    
    export default UserModel;
 