interface AddressModel{
    Address:string;
    City:string
    StateId :string
    CountryId :number;
    id:number
    userId:number
}
export default AddressModel;