import React from 'react'

export default function ShowListComponent() {
  return (
    <div>
      <h1>showlist</h1>
    </div>
  )
}
