import React from 'react'

export default function showList() {
  return (
    <div className='Container'>
      <div className='show-container'>
        <form>
      <h1>showlist</h1>
      </form>
      </div>
    </div>
  )
}
