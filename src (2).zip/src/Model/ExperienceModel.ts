
interface ExperienceModel{
    id:number;
    userId:string;
    companyName:string;
    startYear:number;
    endYear:number;
    designationId:number
}
export default  ExperienceModel;



