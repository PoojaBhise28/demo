
interface ExperienceModel{
    Id:number;
    UserId:string;
    CompanyName:string;
    StartYear:number;
    EndYear:number;
    DesignationId:number
}
export default  ExperienceModel;



