
interface ExperienceModel{
    id:number;
    userId:number;
    companyName:string;
    startYear:number;
    endYear:number;
    designationId:number
}
export default  ExperienceModel;



