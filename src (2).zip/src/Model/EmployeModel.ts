interface EmployeModel {
    
      id:number;
      userId:number
      noticePeriod:number;
      expectedCTC:number
      currentCTC:number;
      
    }
    
    export default EmployeModel;
   