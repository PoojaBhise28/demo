

 interface AcademicModel {

    id:number;
    institutionName:string;
    startYear:string;
    endYear:string;
    percentage:string;
    degree:string;
    UserId:number;

}
export default  AcademicModel;
