interface ResponseModel {
  error: string;
  data: any | null;
  message: string;
  errorCode: string;
}

export default ResponseModel;