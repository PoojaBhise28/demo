import axios from "axios";
import UserModel from "../Model/UserModel";
import { API_URL } from "../APICONFIG";


export async function GetExperienceDetailAsync(
    id: number
  ): Promise<{ data: UserModel[] }> {
    try {
    
  
      const response = await axios.get<UserModel[]>(
        `${API_URL}/ExperienceInfo/` + id
      );
      console.log(response);
      return response;
    } catch (error) {
      throw new Error("Failed to update by id leave data: " + (error as Error).message);
    }
  }

  export async function GetExperienceDetailByIdAsync(
    id: number
  ): Promise<{ data: UserModel[] }> {
    try {
    
  
      const response = await axios.get<UserModel[]>(
        `http://localhost:5203/api/ExperienceInfo/ByUserId/` + id
      );
      console.log(response);
      return response;
    } catch (error) {
      throw new Error("Failed to update by id leave data: " + (error as Error).message);
    }
  }
  export const CreateExperienceDetaiAsync = async (data: any) => {
    try {
      const response = await axios.post(
        `http://localhost:5203/api/ExperienceInfo`,
        data
      );
      console.table(response);
      return response.data;
    } catch (error) {
      throw new Error("Failed to create: " + (error as Error).message);
    }
  };

  export const UpdateExperienceDetailAsync = async (data: any, id: number) => {
    try {
      const res = await axios.put(`http://localhost:5203/api/ExperienceInfo/${id}`, data);
      console.table(res);
      return res.data;
    } catch (error) {
      throw new Error("Failed to update leave data: " + (error as Error).message);
    }
  };
  
  export const DeleteExperienceDetailAsync = async (id: number) => {
    try {
      const res = await axios.delete(
        `http://localhost:5203/api/ExperienceInfo/${id}`
      );
      console.table(res);
      console.log("Deleted sucessfully");
  
      return res.data;
    } catch (error) {
      throw new Error("Failed to delete leave data: " + (error as Error).message);
    }
  };
  