import axios from "axios";
import { API_URL } from "../APICONFIG";
import UserModel from "../Model/UserModel";

export const CreateUserAsync = async (data: UserModel) => {
  
  try {
    
    const res = await axios.post(`http://localhost:5203/api/user`, data);
    
     return res.data;
  } catch (error) {
    alert("Not updated");
     throw new Error("Failed to update leave data: " + (error as Error).message);
    //console.error(error);
  }

};