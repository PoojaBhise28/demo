interface AddressModel{
    address:string;
    city:string
    stateId :number
    countryId :number;
    
    id:number
    userId:number
}
export default AddressModel;