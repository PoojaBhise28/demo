interface AddressModel{
    Address:string;
    City:string
    StateId :string
    CountryId :number;
    id:number
}
export default AddressModel;