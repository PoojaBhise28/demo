import React from 'react'

export default function AcademicDetailComponent() {
  return (
    <div className='Container'>
        <div className='Academic-Container'>
            <form>
            <h1>Academic Details</h1>
            <label htmlFor="InstitutionName">Institution Name</label>
          <input
            type="text"
            name="InstitutionName"
            id="InstitutionName"
            placeholder="Institution Name"
            autoComplete="off"
            maxLength={4}
            // onChange={employeeUtility.onInputChangeEmployee}
            // value={employeeUtility.Employeeinfo.CompanyName}
          />
          
          <label htmlFor="Degree">Degree </label>
          <select

            id="Degree"
            name="Degree"
            //  value={addressUtility.Addressinfo.CountryId}
            //  onChange={addressUtility.onSelectFieldChangeAddress}
          >
            <option value={0}>---Select Country----</option>
            <option value={1}>India</option>
            <option value={2}>USA</option>
            <option value={3}>Japan</option>
            <option value={4}>Canada</option>
          </select>
         <label htmlFor="StartYear">Start Year</label>
          <input
            type="text"
            name="StartYear"
            id="StartYear"
            placeholder="Start Year"
            autoComplete="off"
            maxLength={4}
            // onChange={employeeUtility.onInputChangeEmployee}
            // value={employeeUtility.Employeeinfo.CompanyName}
          />
          <label htmlFor="EndYear">End Year</label>
          <input
            type="text"
            name="EndYear"
            id="EndYear"
            placeholder="End Year"
            autoComplete="off"
            maxLength={4}
            // onChange={employeeUtility.onInputChangeEmployee}
            // value={employeeUtility.Employeeinfo.CompanyName}
          />
          
          <label htmlFor="Percentage">Percentage</label>
          <input
            type="text"
            name="Percentage"
            id="Percentage"
            placeholder="Percentage "
            autoComplete="off"
            maxLength={4}
            // onChange={employeeUtility.onInputChangeEmployee}
            // value={employeeUtility.Employeeinfo.CompanyName}
          />
            </form>
        </div>
     
    </div>
  )
}
