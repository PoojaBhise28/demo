// import React, { useState, useEffect } from "react";

import { useNavigate, useParams } from "react-router-dom";
import UserModel from "../Model/UserModel";
import "../style/showlist.css";
import { useEffect, useState } from "react";
import PersonalModel from "../Model/PersonalModel";
import AddressModel from "../Model/AddressModel";



export default function ShowList() {
   const [PersonalInfo, setPersonalInfo] = useState<PersonalModel[]>([]);
   const [AddressInfo, setAddressInfo] = useState<AddressModel[]>([]);

  const { id } = useParams();

  const navigatetDetails = useNavigate();

  useEffect(() => {
    async function fetchMyAPI() {
      // const response = await GetPersonInfoAsync(13);
      // const res = await GetAddressInfoAsync(1);

      // setUserInfo(response.data);
      // setAddressInfo(res.data);
      
    }
    fetchMyAPI();
  }, []);


 
  const handelAddressUpdateData = (id: number) => {
    navigatetDetails(`/AddressDetail/${id}`);
  };

  const handelPersonUpdateData = (id: number) => {
    navigatetDetails(`/personalInfo/${id}`);
  };

  const handelPersonDelete = async (id: number) => {
    const confirmation = window.confirm(
      "Are you sure you want to delete this user?"
    );
    if (confirmation) {
      try {
        //await DeletePersonInfoAsync(id);
        alert("User deleted successfully!");
      } catch (error) {
        console.error("Error deleting user:", error);
        alert("An error occurred while deleting user. Please try again later.");
      }
    }
  };
  const handelAddressDelete = async (id: number) => {
    const confirmation = window.confirm(
      "Are you sure you want to delete this user?"
    );
    if (confirmation) {
      try {
        //await DeleteAddressInfoAsync(id);
        alert("User deleted successfully!");
      } catch (error) {
        console.error("Error deleting user:", error);
        alert("An error occurred while deleting user. Please try again later.");
      }
    }
  };

  return (
    <div className="show-container">
      <div className="showPersonalInfo">
        <h1>Personal Data</h1>
        <table className="contact-list">
          <thead>
            <tr>
              <th>Sr. no</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Phone Number</th>
              <th>Mobile Number</th>
              <th>Description</th>
              <th>Update</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {PersonalInfo.map((data, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{data.firstName}</td>
                <td>{data.lastName}</td>
                <td>{data.phoneNumber}</td>
                <td>{data.mobileNumber}</td>
                <td>{data.description}</td>
                <td>
                  <button
                    type="button"
                    onClick={() => handelPersonUpdateData(data.id)}
                  >
                    Edit
                  </button>
                </td>
                <td>
                  <button
                    type="button"
                    onClick={() => handelPersonDelete(data.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="showAddress">
        <h1>Address Dtails</h1>
        <table className="AddressData">
          <thead>
            <tr>
              <th>Sr. no</th>
              <th>Address</th>
              <th>City</th>
              <th>State Id</th>
              <th>Country Id</th>
              <th>Description</th>
              <th>Update</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {AddressInfo.map((Addressdata, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{Addressdata.Address}</td>
                <td>{Addressdata.City}</td>
                <td>{Addressdata.StateId}</td>
                <td>{Addressdata.CountryId}</td>

                <td>
                  <button
                    type="button"
                    onClick={() => handelAddressUpdateData(Addressdata.id)}
                  >
                    Edit
                  </button>
                </td>
                <td>
                  <button
                    type="button"
                    onClick={() => handelAddressDelete(Addressdata.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
