import { useState } from "react";
import PersonalModel from "../Model/PersonalModel";
import { useNavigate } from "react-router-dom";

export default function PersonalInfoUtility(){

    const navigate=useNavigate();
    const initialValue : PersonalModel = {
        firstName: "",
        lastName: "",

        mobileNumber: "",
        phoneNumber: "",
        description: "",
        userId: 1,
        IsActive: false,
        id: 0
    };

    const[personalinfo, setPersonalinfo ] =  useState<PersonalModel>(initialValue);
    
    const handelSavePersonalInfo = async() => {
        alert(JSON.stringify(personalinfo));

        
    //const fetchData =  await    CreatePersonalInfo(personalinfo);
    //console.log(fetchData.error);
    //console.log(fetchData.response.status);
    //console.log(fetchData.response.data.status);
    //alert(JSON.stringify(fetchData));
    //alert(JSON.stringify(fetchData.data));
    };

    const handelShowList =()=>{
        navigate("/showlist");
    }

    const onInputChangePersonal = (event: React.ChangeEvent<HTMLInputElement>) =>{
        var name  = event.currentTarget.name;
        var newValue  =  event.currentTarget.value;
        setPersonalinfo((prev)=> ({...prev , [name]: newValue}));
    }

    const onTextAreaChangePersonalDetails = (event: React.ChangeEvent<HTMLTextAreaElement>) =>{
        var name  = event.currentTarget.name;
        var newValue  =  event.currentTarget.value;
        setPersonalinfo((prev)=> ({...prev , [name]: newValue}));
    }
    return{personalinfo,setPersonalinfo,handelSavePersonalInfo,onTextAreaChangePersonalDetails,onInputChangePersonal,handelShowList};
}