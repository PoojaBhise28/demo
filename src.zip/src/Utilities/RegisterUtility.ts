import { useState } from "react";
import PersonalModel from "../Model/PersonalModel";
import UserModel from "../Model/UserModel";

export default function RegisterUtilities() {
    const initialValue : UserModel = {
        emailAddress: "",
        password: "",
        userId: 0,
        id: 0
    }
    const[Registerinfo, setRegisterInfo] =  useState<UserModel>(initialValue);

    const handelRegister = async() => {
    
        alert(JSON.stringify(Registerinfo));
   
    };

    const onInputChangeRegister = (event: React.ChangeEvent<HTMLInputElement>) =>{
        var name  = event.currentTarget.name;
        var newValue  =  event.currentTarget.value;
        setRegisterInfo((prev)=> ({...prev , [name]: newValue}));
    }

    return{setRegisterInfo,Registerinfo,handelRegister,onInputChangeRegister};
}


